public class Computer {

    private  Processor p;
    private  Memory m;
    private  Storage s;

    public Computer(Processor p, Memory m, Storage s) {
        this.p = p;
        this.m = m;
        this.s = s;
    }

    public Processor getP() {
        return p;
    }

    public void setP(Processor p) {
        this.p = p;
    }

    public Memory getM() {
        return m;
    }

    public void setM(Memory m) {
        this.m = m;
    }

    public Storage getS() {
        return s;
    }

    public void setS(Storage s) {
        this.s = s;
    }

    @Override
    public String toString() {
        return "Computer{" +
                "p=" + p +
                ", m=" + m +
                ", s=" + s +
                '}';
    }

    public static void main(String[] args) {

        Processor p1 = new Processor("Intel", "i9", 3);
        Memory m1 = new Memory("Corsair", "RAM", 1000);
        Storage s1 = new Storage("Samsung", "T3", 1000);

        Computer c = new Computer(p1,m1,s1);
        System.out.println(c);


    }
}