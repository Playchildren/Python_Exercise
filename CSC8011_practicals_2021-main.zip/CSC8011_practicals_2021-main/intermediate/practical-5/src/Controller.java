import java.util.ArrayList;

public class Controller {
    public ArrayList<Garage> garages = new ArrayList<>();
    public ArrayList<Car> cars = new ArrayList<>();

    public boolean addCar(Car c) {
        if (!cars.contains(c)) {
            return cars.add(c);
        } else {
            return false;
        }
    }

    public boolean addGarage(Garage g) {
        if (!garages.contains(g)) {
            return garages.add(g);
        } else {
            return false;
        }
    }

    public ArrayList<Car> filterCarByAge(int age) {

        ArrayList<Car> tmp = new ArrayList<>();

        for (Car c : cars) {
            if (c.getAge() == age) {
                tmp.add(c);
            }
        }
        return tmp;
    }

    public ArrayList<Car> filterCarByMake(String make) {

        ArrayList<Car> tmp = new ArrayList<>();

        for (Car c : cars) {
            if (c.getMake().equals(make)) {
                tmp.add(c);
            }
        }
        return tmp;

    }

    public ArrayList<Car> filterYoungerCars(int age) {

        ArrayList<Car> tmp = new ArrayList<>();

        for (Car c : cars) {
            if (c.getAge() < age) {
                tmp.add(c);
            }
        }
        return tmp;
    }
}