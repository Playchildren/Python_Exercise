import java.util.HashMap;
public class PhoneBook {
    public static void main(String[] arg){
        HashMap<String, String> phoneBook =new HashMap<>();
        phoneBook.put("Charles Naismith", "01234 567890");
        phoneBook.put("Lisa Jones", "0987 654321");
        phoneBook.put("William McGonagle", "0555 555666");

        String phoneNumber = phoneBook.get("Lisa Jones");
        System.out.println(phoneNumber);
    }
}
