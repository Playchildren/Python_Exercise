import java.util.Scanner;

public class IO {

    public static void main(String[] args) {
        new IO().run();
    }

    public void run() {
        Controller c = new Controller();

        boolean quit = false;
        Scanner sc = new Scanner(System.in);

        while(!quit){
            Scanner input = new Scanner(System.in);
            menu();
            System.out.println("Please select an option");
            int choice = sc.nextInt();


            switch (choice){
                case 1:
                    c.addCar(recordCar());
                    break;
                case 2:
                    c.addGarage(recordGarage());
                    break;
                case 3:
                    System.out.println("Please input an age to filter by");
                    int age = input.nextInt();
                    System.out.println(c.filterCarByAge(age));
                    break;
                case 4:
                    System.out.println("Please input the make you would like " +
                            "to filter by");

                    String make = input.nextLine();
                    System.out.println(c.filterCarByMake(make));
                    break;
                case 5:
                    System.out.println("Please enter the filter age");
                    int ageYounger = input.nextInt();
                    System.out.println(c.filterYoungerCars(ageYounger));
                    break;
                case 6:
                    System.out.println("Quitting");
                    quit = true;
                    break;
                default:
                    System.out.println("Not a valid option");
            }
        }


    }
    private Car recordCar() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Please Enter the Cars make");
        String make = sc.nextLine();
        System.out.println("Please Enter the Cars model");
        String model = sc.nextLine();
        System.out.println("Please Enter the Cars age");
        int age = sc.nextInt();
        return new Car(make,model,age);
    }

    private Garage recordGarage() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Please Enter the Garage Name");
        String name = sc.nextLine();
        System.out.println("Please Enter the Garage first line address");
        String fline = sc.nextLine();
        System.out.println("Please Enter the Garage postcode");
        String postcode = sc.nextLine();
        System.out.println("Please Enter the Garage car capacity");
        int cap = sc.nextInt();
        return new Garage(name,fline,postcode,cap);
    }

    private void menu() {
        System.out.println("1: Add a Car\n" +
                "2: Add a Garage\n " +
                "3: filter all cars with a given age\n" +
                "4: filter all cars with a given make\n" +
                "5: filter all cars that are younger than a given age\n\n");
    }
}