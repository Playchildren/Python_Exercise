import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;


public class Book {

    private final String title;
    private final String author;
    private final String genre;
    private final String publisher;
    private final int pageNumber;


    public Book(String title, String author, String genre, String publisher, int pageNumber) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.publisher = publisher;
        this.pageNumber = pageNumber;

    }

    public String getTitle(){
      return title;
    }

    public String getAuthor(){
        return author;
    }

    public String getGenre(){
        return genre;
    }

    public String getPublisher(){
        return publisher;
    }

    public int getPageNumber(){
        return pageNumber;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", genre='" + genre + '\'' +
                ", publisher='" + publisher + '\'' +
                ", pageNumber=" + pageNumber +
                "}";
    }



    public static void main(String[] arg) throws FileNotFoundException {
        Book b1 = new Book("Fake Book", "Fake Author", "Fake Genre", "Fake Publisher", 250);
        System.out.println(b1);

        File fileName = new File(Book.class.getResource("books.csv").getFile());
        Scanner myReader = new Scanner(fileName);

        ArrayList<String> records = new ArrayList<>();

        while(myReader.hasNext()){
            records.add(myReader.nextLine());
        }

        for (String line : records) {
            String[] elements = line.split(",");
            Book b = new Book(elements[0],elements[1],elements[2],
                    elements[3],
                    Integer.parseInt(elements[4]));
            System.out.println(b);
        }
    }

}