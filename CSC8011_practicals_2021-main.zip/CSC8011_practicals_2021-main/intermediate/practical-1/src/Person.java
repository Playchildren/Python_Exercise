public class Person{

    private String name;
    private double height;
    private double weight;

    public Person(String name, double height, double weight) {
        this.name = name;
        checkPositive(height, name);
        this.height = height;
        checkPositive(weight, name);
        this.weight = weight;
    }

    private void checkPositive(double i, String name) {
        if (i <= 0) {
            throw new IllegalArgumentException(name + " must be positive");
        }
    }

    public String getName() {
        return name;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        checkPositive(height, " Height:");
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        checkPositive(weight, "Weight:");
        this.weight = weight;
    }

    public double getBMI() {
        return getWeight() / (getHeight() * getHeight());
    }

    public void setImperial(double heightInches, double weightStones) {
        setHeight(heightInches * 2.54 / 100);
        setWeight(weightStones * 6.35);
    }

    public String getBMIStatus() {
        double bmi = getBMI();

        if (bmi < 16) {
            return "Severely Underweight";
        }
        if (bmi < 18.5) {
            return "Underweight";
        }
        if (bmi < 25) {
            return "Normal";
        }
        if (bmi < 30) {
            return "Overweight";
        }
        if (bmi < 35) {
            return "Obese Class I";
        }
        if (bmi < 40) {
            return "Obese Class II";
        }

        return "Obese Class III";
    }

    public String format(){
        return String.format( "Name:\t%s\n" +
                "Height:\t%s\n" +
                "Weight:\t%s\n" +
                "BMI Status:\t%s\n", getName(), getHeight(),
                getWeight(), getBMIStatus());
    }

    public void display(){
        System.out.println( format() );
    }

    public static void main(String[] args) {
        Person p = new Person("Harry", 1.85, 80);
        p.display();
    }
}