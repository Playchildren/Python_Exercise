import java.util.ArrayList;
import java.util.Arrays;

public class Garage {

    private String name;
    private String[] address = new String[2];
    private int carCapacity;

    private ArrayList<Car> carsInGarage;

    Garage(String name, String firstLineAddress, String postCode, int carCapacity){
        this.name = name;
        this.address[0] = firstLineAddress;
        this.address[1] = postCode;
        this.carCapacity = carCapacity;
        this.carsInGarage = new ArrayList<>();
    }

    private boolean checkCarAgeValid(Car c){
        return c.getAge() >= 0 && c.getAge() <= 30;
    }

    public String[] getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCarCapacity() {
        return carCapacity;
    }

    public void setCarCapacity(int carCapacity) {
        this.carCapacity = carCapacity;
    }

    public ArrayList<Car> getCarsInGarage() {
        return carsInGarage;
    }

    public String addressNicePrint(){
        return String.format("First Line of Address: %s\nPostcode: %s",
                address[0],address[1]);
    }


    public boolean addCar(Car c){
        if(checkCarAgeValid(c)) {
            if (!carsInGarage.contains(c)) {
                return carsInGarage.add(c);
            }
            else {
                return false;
            }
        }
        else{
            return false;
        }
    }

    public ArrayList<Car> filterCarsByGivenAge(int age){

        ArrayList<Car> tmp = new ArrayList<>();
        for (Car c : carsInGarage){
            if(c.getAge() > age){
                tmp.add(c);
            }
        }
        return tmp;
    }

    public String neatPrint(){
        String tmp = "";

        for (Car c: carsInGarage) {
            tmp+=  String.format("Make: %s\n Model: %s\n Age: %s\n",
                    c.getMake(),c.getModel(),c.getAge());
        }
        return tmp;
    }

    @Override
    public String toString() {
        return "Garage{" +
                "name='" + name + '\'' +
                ", address=" + Arrays.toString(address) +
                ", carCapacity=" + carCapacity +
                ", carsInGarage=" + carsInGarage +
                '}';
    }
}