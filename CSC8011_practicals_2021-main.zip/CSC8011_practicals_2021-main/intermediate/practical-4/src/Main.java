public class Main {
            public static void main(String[] args) {


                Car c1 = new Car("Citroen","C1", -5);
                Car c2 = new Car("Ford","Fiesta", 5);
                Car c3 = new Car("Mazda","2", 10);
                Car c4 = new Car("Nissan","Juke", 3);
                Car c5 = new Car("Audi","S3", 80);
                Car c6 = new Car("BMW","1", 2);


                Garage g = new Garage("Jordans Garage","1 Fake Street","FAK3NE", 3);
                g.addCar(c1);
                g.addCar(c2);
                g.addCar(c3);
                g.addCar(c4);
                g.addCar(c5);
                g.addCar(c6);

                System.out.println(g.neatPrint());

            }
        }
