import java.util.Arrays;

public class Days {
    static String[] Days = {
            "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday", "Sunday"};

    static String[] Months = {
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
            "Sep", "Oct", "Nov", "Dec"
    };

    static int[] Fibonacci = {
            1, 1, 2, 3, 5, 8, 13, 21, 34, 55
    };

    public static void main(String arg[]){
        DAYS();
        MONTHS();
        FIBONACCI();
    }

    public static void DAYS(){
        for(String day: Days){
            System.out.println(day);
        }
    }

    public static void MONTHS(){
        int j = 0;
        while(j < Months.length){
            System.out.println(Months[j]);
            j++;
        }
    }

    public static void FIBONACCI(){
        int doubleFib[] = new int[Fibonacci.length];
        for(int k = 0; k < Fibonacci.length; k++){
            System.out.println(Fibonacci[k]);
            doubleFib[k] = 2 * Fibonacci[k];
        }
        System.out.println(Arrays.toString(doubleFib));
    }

}
