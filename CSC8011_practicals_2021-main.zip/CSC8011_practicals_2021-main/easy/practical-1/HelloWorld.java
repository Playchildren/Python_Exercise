public class HelloWorld {
    
    public static void main(String[] args) {
        int x = 250;
        int y = 72;
        System.out.println("CSC8011 Introduction to Software Engineering");
        System.out.println(x + y);
        System.out.println("Hello World");
        additions(); //ignore for now
        fancyPrint(); // ignore for now
    }
    
    public static void additions() {
        int x = 100;
        int y = 50;
        int z = x + y;
        System.out.println(z);
    }
    
    public static void fancyPrint() {
        System.out.println("   J    a   v     v  a                                                                                        \n" +
                           "   J   a a   v   v  a a                                                                                       \n" +
                           "J  J  aaaaa   V V  aaaaa                                                                                      \n" +
                           " JJ  a     a   V  a     a ");
    }
}