public class Power {

    public static void main(String[] args) {
        Power p = new Power();
        int x = 6;
        System.out.println("The square of " + x +
                " is: " + p.square(x));

        System.out.println("The cube of " + x +
                " is: " + p.cube(x));

        System.out.println("The hypercube of " + x +
                " is: " + p.hypercube(x));

        p.square(5);
    }

    public int square(int x) {
        return x * x;
    }

    public int cube(int x) {
        return x * square(x);
    }

    public int hypercube(int x) {
        return x * cube(x);
    }

//    public int power(int x, int n) {
//        if (n == 1) {
//            return x;
//        }
//        if (n == 2) {
//            return square(x);
//        }
//        if (n == 3) {
//            return cube(x);
//        }
//        if (n == 4) {
//            return hypercube(x);
//        }
//
//        // exceptions also good!
//        return 0;
//    }
}