public class Circle {

    public static void main(String[] args) {
        double radius = 7.5;
        System.out.println("Per is " + 2 * Math.PI * radius);
        System.out.println("Area is " + Math.PI * (radius * radius));
    }
}
