public class Triangle {

    public static void main(String[] args) {
        final double width = 5.6;
        final double height = 8.5;
        double area = width * height;
        double per = 2 * (width + height);
        System.out.println(area);
        System.out.println(per);
    }
}
