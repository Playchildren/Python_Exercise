import java.util.Scanner;

public class Input {
    public static void main(String[] args) {
        String text1, text2;
        Scanner s = new Scanner(System.in);
        text1 = s.nextLine();
        System.out.println("you said1 " + text1);
        text2 = s.nextLine();
        System.out.println("you said2 " + text2);

    }
}
