import java.util.function.BinaryOperator;

public class Variables {

    public static void main(String[] args) {
        String name = "Chuan";
        int cards = 52;
        boolean happy = true;
        float change = 2.5F;

        System.out.println(name);
        System.out.println(cards);
        System.out.println(happy);
        System.out.println(change);

        binaryToDecimal(); //ignore
        binaryToOctal(); //ignore
        binaryToHex(); //ignore

    }


    public static void binaryToDecimal() {

        String binary = "1010";
        int decimal = Integer.parseInt(binary, 2);
        System.out.println(decimal);

    }

    public static void binaryToOctal() {

        String binary = "1010";
        System.out.println(Integer.toOctalString(Integer.parseInt(binary, 2)));

    }

    public static void binaryToHex() {

        String binary = "1010";
        System.out.println(Integer.toHexString(Integer.parseInt(binary, 2)));

    }
}