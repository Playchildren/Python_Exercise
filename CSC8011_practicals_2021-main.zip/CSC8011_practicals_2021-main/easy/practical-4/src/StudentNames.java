import java.util.Arrays;
import java.util.Scanner;

public class StudentNames {
    public static void main(String[] args) {
        int max_number = 8;
        String[] names = new String[max_number];
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < max_number; i++) {
            System.out.println("Enter student name:");
            names[i] = s.next();
        }
        System.out.println(Arrays.toString(names));
    }
}
