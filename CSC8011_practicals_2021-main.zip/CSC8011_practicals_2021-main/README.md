# CSC8011_practicals_2021

A collection of "easy" and intermediate practical exercises to get you started with Java programming.

Check the branch "solutions" to see sample solutions to some exercises.
